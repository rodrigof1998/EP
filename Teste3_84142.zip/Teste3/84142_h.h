struct dados {unsigned int byte1;unsigned int byte2; unsigned int byte3; unsigned int byte4; float temp;};

typedef struct dados dados_t ;

dados_t registerValue();
